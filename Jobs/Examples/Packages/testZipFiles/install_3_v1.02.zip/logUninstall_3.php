<?php
$GLOBALS['log']->fatal("Test Package #3.02 Uninstalled");