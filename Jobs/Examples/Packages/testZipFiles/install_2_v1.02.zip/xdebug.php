<?php
xdebug_info();