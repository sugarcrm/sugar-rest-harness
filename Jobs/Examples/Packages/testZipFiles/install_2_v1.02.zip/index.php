<?php
print("<h1>PHP Works!</h1>");