<?php
$GLOBALS['log']->fatal("Test Package #2.02 Uninstalled");