<?php
$GLOBALS['log']->fatal("Test Package #5.01 Installed");