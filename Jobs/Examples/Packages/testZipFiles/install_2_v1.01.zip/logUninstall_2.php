<?php
$GLOBALS['log']->fatal("Test Package #2.01 Uninstalled");