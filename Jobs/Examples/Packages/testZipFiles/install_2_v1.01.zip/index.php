<?php
print("<h1>PHP Sub-directory Works!</h1>");