<?php
$GLOBALS['log']->fatal("Test Package #1.02 Installed");