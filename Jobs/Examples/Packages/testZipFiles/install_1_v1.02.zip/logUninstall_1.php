<?php
$GLOBALS['log']->fatal("Test Package 1 v1.02 Uninstalled");