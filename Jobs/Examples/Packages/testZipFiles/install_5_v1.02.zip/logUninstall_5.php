<?php
$GLOBALS['log']->fatal("Test Package #5.02 Uninstalled");