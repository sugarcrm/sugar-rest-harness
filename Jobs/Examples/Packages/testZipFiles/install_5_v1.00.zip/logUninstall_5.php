<?php
$GLOBALS['log']->fatal("Test Package #5.00 Uninstalled");