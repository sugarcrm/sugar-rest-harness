<?php
$GLOBALS['log']->fatal("Test Package #1.00 Installed");