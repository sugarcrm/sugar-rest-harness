<?php
$GLOBALS['log']->fatal("Test Package #4.01 Installed");