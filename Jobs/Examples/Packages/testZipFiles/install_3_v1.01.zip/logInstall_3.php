<?php
$GLOBALS['log']->fatal("Test Package #3.01 Installed");
chdir('/Library/WebServer/Documents/sugarcrm');