<?php
$GLOBALS['log']->fatal("Test Package #1.01 Uninstalled");