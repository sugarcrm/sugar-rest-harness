<?php
$GLOBALS['log']->fatal("Test Package #3.00 Uninstalled");