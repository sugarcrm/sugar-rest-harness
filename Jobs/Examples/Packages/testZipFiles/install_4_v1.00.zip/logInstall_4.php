<?php
$GLOBALS['log']->fatal("Test Package #4.00 Installed");